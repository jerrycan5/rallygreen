import React from 'react';
import { Link } from 'react-router-dom';
import { FaArrowLeft } from "react-icons/fa";

const VipCheckout = () => {
  return (
    <div className="min-h-screen bg-brand.light text-black font-sans px-5 py-3">
      {/* Back Button */}
      <div className="flex items-center mb-3">
        <Link
          to={-1}
          onClick={(e) => {
            e.preventDefault();
            window.history.length > 1
              ? window.history.back()
              : window.location.assign('/');
          }}
          className="flex items-center text-black font-medium"
        >
          <FaArrowLeft className="mr-1" />
          Go Back
        </Link>
      </div>

      {/* Hero Image */}
    <div className="relative w-full h-[220px]">
        <img
          src="/signup.jpeg"
          alt="a date with reil"
          className="w-full h-full object-cover"
        />
      </div>

      {/* Title */}
      <h2 className="text-center text-xl font-bold text-brand.deep mb-6">
        A date with Riley Green
      </h2>

      {/* Form */}
      <form className="space-y-4">
        <p className="text-sm font-semibold text-brand.gray mb-2">Fill Contact Profile</p>
        <input
          type="text"
          placeholder="Full Name"
          className="w-full px-4 py-3 bg-[#e5dbb3] rounded-full placeholder:text-gray-600 text-sm"
        />
        <input
          type="email"
          placeholder="Email Address"
          className="w-full px-4 py-3 bg-[#e5dbb3] rounded-full placeholder:text-gray-600 text-sm"
        />
        <input
          type="text"
          placeholder="United State"
          className="w-full px-4 py-3 bg-[#e5dbb3] rounded-full placeholder:text-gray-600 text-sm"
        />
        <input
          type="text"
          placeholder="Street Address"
          className="w-full px-4 py-3 bg-[#e5dbb3] rounded-full placeholder:text-gray-600 text-sm"
        />
        <input
          type="text"
          placeholder="State"
          className="w-full px-4 py-3 bg-[#e5dbb3] rounded-full placeholder:text-gray-600 text-sm"
        />
        <input
          type="text"
          placeholder="City"
          className="w-full px-4 py-3 bg-[#e5dbb3] rounded-full placeholder:text-gray-600 text-sm"
        />
        <input
          type="text"
          placeholder="Zip code"
          className="w-full px-4 py-3 bg-[#e5dbb3] rounded-full placeholder:text-gray-600 text-sm"
        />

        <button
          type="submit"
          className="mx-auto block px-6 py-1 border border-brand.deep rounded-full text-black font-semibold text-sm hover:bg-brand.deep hover:text-white transition"
        >
          Send
        </button>
      </form>
    </div>
  );
};

export default VipCheckout;
