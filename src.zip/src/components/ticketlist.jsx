import React from "react";
import { useNavigate } from "react-router-dom";
import { FaArrowLeft } from "react-icons/fa";

const tickets = Array.from({ length: 20 }, () => ({
  date: "AUG 1 2025",
  event: "Musikfest",
  location: "Bethlehem, PA",
}));

export default function TicketList() {
  const navigate = useNavigate();

  return (
    <div className="min-h-screen bg-brand-deep text-white font-sans px-4 py-6 space-y-6">
        <button
           className="flex items-center text-blue-600 hover:text-blue-800 mb-6"
           onClick={() => navigate(-1)}
         >
           <FaArrowLeft className="mr-2" />
           <span className="font-medium">Back</span>
         </button>

      {tickets.map((ticket, index) => (
        <div key={index} className="space-y-2">
          <div className="text-center">
            <p className="text-sm">{ticket.date}</p>
            <p className="font-semibold text-md">{ticket.event}</p>
            <p className="text-sm text-gray-300">{ticket.location}</p>
          </div>

          <div className="flex flex-col items-center space-y-2">
            <button
              className="bg-white text-black font-bold px-8 py-1 rounded-sm w-full max-w-xs"
              onClick={() => navigate("/vipticket")}
            >
              VIP
            </button>
            <button className="bg-white text-black font-bold px-8 py-1 rounded-sm w-full max-w-xs">
              TICKETS
            </button>
          </div>
        </div>
      ))}
    </div>
  );
}
