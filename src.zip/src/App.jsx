// src/App.jsx
import React from 'react';
import { Routes, Route } from 'react-router-dom'
import RileyGreenPage from './pages/RileyGreenPage'
import TicketList from './components/ticketlist'
import Vipticket from './components/vipticket'
import VipCheckout from './components/vipcheckout'
import VipPackagesPage from './components/ VipPackages';
import Signup from './components/Signup';

function App() {
  return (
    <Routes>
      <Route path="/" element={<RileyGreenPage />} />
      <Route path="/ticketlist" element={<TicketList />} />
      <Route path="/vipticket" element={<Vipticket />} />
      <Route path="/vipcheckout" element={<VipCheckout />} />
      <Route path="/vip-packages" element={<VipPackagesPage />} />
      <Route path="/signup" element={<Signup />} />

    </Routes>
  );
}

export default App;